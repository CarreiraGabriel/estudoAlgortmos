const { lista1000asc, lista1000Unsorted, lista1000desc, lista10000asc, lista100000asc, lista10000Unsorted, lista10000desc, lista100000Unsorted, lista100000desc } = require('./constants');

function bubbleSort(vetor) {
    let tempoInicio = performance.now();  // Inicia o tempo de execução
    let n = vetor.length;
    let quantidadeTrocas = 0;
    let quantidadeComparacoes = 0;

    // Loop para passar por todos os elementos do vetor
    for (let i = 0; i < n - 1; i++) {
        for (let j = 0; j < n - i - 1; j++) {
            quantidadeComparacoes++;  // Contabiliza cada comparação feita

            // Se o elemento da esquerda for maior que o da direita, troca
            if (vetor[j] > vetor[j + 1]) {
                // Troca os elementos
                [vetor[j], vetor[j + 1]] = [vetor[j + 1], vetor[j]];
                quantidadeTrocas++;  // Contabiliza a troca
            }
        }
    }

    let tempoFim = performance.now();  // Finaliza o tempo de execução
    let tempoExecucao = tempoFim - tempoInicio;  // Calcula o tempo total

    return {
        vetorOrdenado: vetor,  // Retorna o vetor ordenado
        tempoExecucao: tempoExecucao,  // Tempo de execução em milissegundos
        quantidadeTrocas: quantidadeTrocas,  // Número de trocas
        quantidadeComparacoes: quantidadeComparacoes  // Número de comparações
    };
}

function improvedBubbleSort(vetor) {
    let tempoInicio = performance.now();  // Inicia o tempo de execução
    let n = vetor.length;
    let quantidadeTrocas = 0;
    let quantidadeComparacoes = 0;
    let trocou;  // Flag para verificar se houve troca

    // Loop para passar por todos os elementos do vetor
    for (let i = 0; i < n - 1; i++) {
        trocou = false;  // Reinicia a flag de troca a cada iteração

        for (let j = 0; j < n - i - 1; j++) {
            quantidadeComparacoes++;  // Contabiliza cada comparação feita

            // Se o elemento da esquerda for maior que o da direita, troca
            if (vetor[j] > vetor[j + 1]) {
                // Troca os elementos
                [vetor[j], vetor[j + 1]] = [vetor[j + 1], vetor[j]];
                quantidadeTrocas++;  // Contabiliza a troca
                trocou = true;  // Marca que houve uma troca
            }
        }

        // Se nenhuma troca foi feita, o vetor já está ordenado
        if (!trocou) {
            break;
        }
    }

    let tempoFim = performance.now();  // Finaliza o tempo de execução
    let tempoExecucao = tempoFim - tempoInicio;  // Calcula o tempo total

    return {
        vetorOrdenado: vetor,  // Retorna o vetor ordenado
        tempoExecucao: tempoExecucao,  // Tempo de execução em milissegundos
        quantidadeTrocas: quantidadeTrocas,  // Número de trocas
        quantidadeComparacoes: quantidadeComparacoes  // Número de comparações
    };
}

function insertionSort(vetor) {
    let tempoInicio = performance.now();  // Inicia o tempo de execução
    let n = vetor.length;
    let quantidadeTrocas = 0;
    let quantidadeComparacoes = 0;

    // Percorre o vetor a partir do segundo elemento
    for (let i = 1; i < n; i++) {
        let chave = vetor[i];  // O elemento que será inserido na parte ordenada
        let j = i - 1;

        // Move os elementos maiores que a chave para uma posição à frente
        while (j >= 0 && vetor[j] > chave) {
            quantidadeComparacoes++;  // Contabiliza a comparação
            vetor[j + 1] = vetor[j];  // Move o elemento
            j--;
            quantidadeTrocas++;  // Contabiliza a troca
        }

        // Coloca a chave na posição correta
        vetor[j + 1] = chave;

        // Se a chave foi inserida sem precisar de trocas, incrementa a comparação final
        if (j >= 0) {
            quantidadeComparacoes++;  // Contabiliza a comparação quando a chave é maior que o valor à esquerda
        }
    }

    let tempoFim = performance.now();  // Finaliza o tempo de execução
    let tempoExecucao = tempoFim - tempoInicio;  // Calcula o tempo total

    return {
        vetorOrdenado: vetor,  // Retorna o vetor ordenado
        tempoExecucao: tempoExecucao,  // Tempo de execução em milissegundos
        quantidadeTrocas: quantidadeTrocas,  // Número de trocas
        quantidadeComparacoes: quantidadeComparacoes  // Número de comparações
    };
}

function selectionSort(vetor) {
    let tempoInicio = performance.now();  // Inicia o tempo de execução
    let n = vetor.length;
    let quantidadeTrocas = 0;
    let quantidadeComparacoes = 0;

    // Percorre todo o vetor
    for (let i = 0; i < n - 1; i++) {
        let indiceMinimo = i;  // Inicializa o índice do menor valor

        // Encontra o índice do menor elemento no vetor não ordenado
        for (let j = i + 1; j < n; j++) {
            quantidadeComparacoes++;  // Contabiliza a comparação

            if (vetor[j] < vetor[indiceMinimo]) {
                indiceMinimo = j;  // Atualiza o índice do menor valor
            }
        }

        // Se o menor valor não está na posição atual, troca os elementos
        if (indiceMinimo !== i) {
            [vetor[i], vetor[indiceMinimo]] = [vetor[indiceMinimo], vetor[i]];
            quantidadeTrocas++;  // Contabiliza a troca
        }
    }

    let tempoFim = performance.now();  // Finaliza o tempo de execução
    let tempoExecucao = tempoFim - tempoInicio;  // Calcula o tempo total

    return {
        vetorOrdenado: vetor,  // Retorna o vetor ordenado
        tempoExecucao: tempoExecucao,  // Tempo de execução em milissegundos
        quantidadeTrocas: quantidadeTrocas,  // Número de trocas
        quantidadeComparacoes: quantidadeComparacoes  // Número de comparações
    };
}

function mergeSort(vetor) {
    let tempoInicio = performance.now();  // Inicia o tempo de execução
    let quantidadeTrocas = 0;
    let quantidadeComparacoes = 0;

    // Função para mesclar dois subvetores
    function merge(esquerda, direita) {
        let resultado = [];
        let i = 0, j = 0;

        // Mescla os dois subvetores em ordem crescente
        while (i < esquerda.length && j < direita.length) {
            quantidadeComparacoes++;  // Contabiliza a comparação

            if (esquerda[i] < direita[j]) {
                resultado.push(esquerda[i]);
                i++;
            } else {
                resultado.push(direita[j]);
                j++;
            }
        }

        // Concatena os elementos restantes
        resultado = resultado.concat(esquerda.slice(i), direita.slice(j));

        return resultado;
    }

    // Função recursiva para dividir o vetor
    function dividir(vetor) {
        if (vetor.length <= 1) {
            return vetor;
        }

        let meio = Math.floor(vetor.length / 2);
        let esquerda = dividir(vetor.slice(0, meio));
        let direita = dividir(vetor.slice(meio));

        return merge(esquerda, direita);
    }

    // Ordena o vetor
    let vetorOrdenado = dividir(vetor);

    let tempoFim = performance.now();  // Finaliza o tempo de execução
    let tempoExecucao = tempoFim - tempoInicio;  // Calcula o tempo total

    return {
        vetorOrdenado: vetorOrdenado,  // Retorna o vetor ordenado
        tempoExecucao: tempoExecucao,  // Tempo de execução em milissegundos
        quantidadeTrocas: quantidadeTrocas,  // O Merge Sort não faz trocas explícitas
        quantidadeComparacoes: quantidadeComparacoes  // Número de comparações
    };
}

function quickSort(vetor) {
    let tempoInicio = performance.now();  // Inicia o tempo de execução
    let quantidadeTrocas = 0;
    let quantidadeComparacoes = 0;

    // Função para dividir o vetor com base em um pivô
    function particionar(vetor, inicio, fim) {
        let pivo = vetor[fim];  // Pivô é o último elemento
        let i = inicio - 1;

        for (let j = inicio; j < fim; j++) {
            quantidadeComparacoes++;  // Contabiliza a comparação

            // Se o elemento for menor ou igual ao pivô
            if (vetor[j] <= pivo) {
                i++;
                // Troca os elementos apenas se necessário
                if (vetor[i] !== vetor[j]) {
                    [vetor[i], vetor[j]] = [vetor[j], vetor[i]];  // Troca os elementos
                    quantidadeTrocas++;  // Contabiliza a troca
                }
            }
        }

        // Coloca o pivô na posição correta, trocando apenas se necessário
        if (vetor[i + 1] !== vetor[fim]) {
            [vetor[i + 1], vetor[fim]] = [vetor[fim], vetor[i + 1]];
            quantidadeTrocas++;  // Contabiliza a troca
        }

        return i + 1;  // Retorna a posição do pivô
    }

    // Função recursiva para ordenar as sublistas
    function dividir(vetor, inicio, fim) {
        if (inicio < fim) {
            let indicePivo = particionar(vetor, inicio, fim);  // Particiona o vetor
            dividir(vetor, inicio, indicePivo - 1);  // Ordena a parte à esquerda do pivô
            dividir(vetor, indicePivo + 1, fim);  // Ordena a parte à direita do pivô
        }
    }

    // Chama a função de divisão
    dividir(vetor, 0, vetor.length - 1);

    let tempoFim = performance.now();  // Finaliza o tempo de execução
    let tempoExecucao = tempoFim - tempoInicio;  // Calcula o tempo total

    return {
        vetorOrdenado: vetor,  // Retorna o vetor ordenado
        tempoExecucao: tempoExecucao,  // Tempo de execução em milissegundos
        quantidadeTrocas: quantidadeTrocas,  // Número de trocas
        quantidadeComparacoes: quantidadeComparacoes  // Número de comparações
    };
}


function heapSort(vetor) {
    let tempoInicio = performance.now();  // Inicia o tempo de execução
    let quantidadeTrocas = 0;
    let quantidadeComparacoes = 0;

    // Função para ajustar o heap
    function heapify(vetor, n, i) {
        let maior = i;  // Inicializa o maior como a raiz
        let esquerda = 2 * i + 1;  // Índice do filho esquerdo
        let direita = 2 * i + 2;  // Índice do filho direito

        // Verifica se o filho esquerdo é maior que a raiz
        if (esquerda < n && vetor[esquerda] > vetor[maior]) {
            maior = esquerda;
            quantidadeComparacoes++;  // Contabiliza a comparação
        }

        // Verifica se o filho direito é maior que o maior valor atual
        if (direita < n && vetor[direita] > vetor[maior]) {
            maior = direita;
            quantidadeComparacoes++;  // Contabiliza a comparação
        }

        // Se o maior não é a raiz, troca os elementos e continua a ajustar
        if (maior !== i) {
            [vetor[i], vetor[maior]] = [vetor[maior], vetor[i]];
            quantidadeTrocas++;  // Contabiliza a troca

            // Ajusta o heap com o novo índice
            heapify(vetor, n, maior);
        }
    }

    // Função para ordenar o vetor
    function ordenar(vetor) {
        let n = vetor.length;

        // Constrói o heap
        for (let i = Math.floor(n / 2) - 1; i >= 0; i--) {
            heapify(vetor, n, i);
        }

        // Extrai os elementos um a um do heap
        for (let i = n - 1; i > 0; i--) {
            // Move a raiz para o final
            [vetor[0], vetor[i]] = [vetor[i], vetor[0]];
            quantidadeTrocas++;  // Contabiliza a troca

            // Ajusta o heap novamente
            heapify(vetor, i, 0);
        }
    }

    // Chama a função de ordenação
    ordenar(vetor);

    let tempoFim = performance.now();  // Finaliza o tempo de execução
    let tempoExecucao = tempoFim - tempoInicio;  // Calcula o tempo total

    return {
        vetorOrdenado: vetor,  // Retorna o vetor ordenado
        tempoExecucao: tempoExecucao,  // Tempo de execução em milissegundos
        quantidadeTrocas: quantidadeTrocas,  // Número de trocas
        quantidadeComparacoes: quantidadeComparacoes  // Número de comparações
    };
}

function countingSort(vetor) {
    let tempoInicio = performance.now();  // Inicia o tempo de execução
    let quantidadeTrocas = 0;
    let quantidadeComparacoes = 0;  // Removido, pois Counting Sort não realiza comparações

    // Determina o valor máximo e mínimo no vetor
    let max = Math.max(...vetor);
    let min = Math.min(...vetor);

    // Cria um vetor de contagem
    let intervalo = max - min + 1;
    let contagem = new Array(intervalo).fill(0);

    // Conta a ocorrência de cada elemento
    for (let i = 0; i < vetor.length; i++) {
        contagem[vetor[i] - min]++;  // A contagem é feita com base na diferença com o valor mínimo
    }

    let indice = 0;

    // Reconstroi o vetor ordenado
    for (let i = 0; i < contagem.length; i++) {
        while (contagem[i] > 0) {
            vetor[indice] = i + min;  // A posição do valor no vetor original é reconstruída
            indice++;
            contagem[i]--;
            quantidadeTrocas++;  // Contabiliza a troca de elementos
        }
    }

    let tempoFim = performance.now();  // Finaliza o tempo de execução
    let tempoExecucao = tempoFim - tempoInicio;  // Calcula o tempo total

    return {
        vetorOrdenado: vetor,  // Retorna o vetor ordenado
        tempoExecucao: tempoExecucao,  // Tempo de execução em milissegundos
        quantidadeTrocas: quantidadeTrocas,  // Número de trocas
        quantidadeComparacoes: quantidadeComparacoes  // Removido, Counting Sort não realiza comparações
    };
}

console.log(countingSort(lista100000desc));